import os
import requests
import telegram
import asyncio
import schedule
import time
from datetime import datetime, timedelta

BOT_TOKEN = os.getenv("BOT_TOKEN")
CHAT_ID = os.getenv("CHAT_ID")
bot = telegram.Bot(token=BOT_TOKEN)

def get_price_at(symbol, date=None):
    if date:
        date_str = date.strftime("%d-%m-%Y")
        url = f"https://api.coingecko.com/api/v3/coins/{symbol}/history?date={date_str}"
        data = requests.get(url).json()
        return data["market_data"]["current_price"]["usd"]
    else:
        url = f"https://api.coingecko.com/api/v3/simple/price?ids={symbol}&vs_currencies=usd"
        data = requests.get(url).json()
        return data[symbol]["usd"]

def calc_change(current, past):
    change = ((current - past) / past) * 100
    return round(change, 2)

def interpret_trend(change7, change30):
    if change7 > 3 and change30 > 3:
        return "Tăng mạnh"
    elif change7 > 0 and change30 >= 0:
        return "Tăng nhẹ"
    elif change7 < 0 and change30 < 0:
        return "Giảm"
    else:
        return "Đi ngang / biến động nhẹ"

def format_msg(symbol_name, now, c7, c30):
    trend = interpret_trend(c7, c30)
    return f"{symbol_name} hiện tại: {now:,.2f} USD\n- So với 7 ngày trước: {c7:+.2f}%\n- So với 30 ngày trước: {c30:+.2f}%\n→ Xu hướng: {trend}\n"

def send_report():
    try:
        now = datetime.now()
        today = now.strftime("%H:%M %d/%m/%Y")

        btc_now = get_price_at("bitcoin")
        btc_7 = get_price_at("bitcoin", now - timedelta(days=7))
        btc_30 = get_price_at("bitcoin", now - timedelta(days=30))

        eth_now = get_price_at("ethereum")
        eth_7 = get_price_at("ethereum", now - timedelta(days=7))
        eth_30 = get_price_at("ethereum", now - timedelta(days=30))

        btc_c7 = calc_change(btc_now, btc_7)
        btc_c30 = calc_change(btc_now, btc_30)
        eth_c7 = calc_change(eth_now, eth_7)
        eth_c30 = calc_change(eth_now, eth_30)

        msg = f"""[BÁO GIÁ BITCOIN & ETHEREUM]\n\n{format_msg("BTC", btc_now, btc_c7, btc_c30)}\n{format_msg("ETH", eth_now, eth_c7, eth_c30)}Thời gian: {today}"""

        bot.send_message(chat_id=CHAT_ID, text=msg)
        print("Đã gửi báo giá.")
    except Exception as e:
        print("Lỗi khi gửi báo giá:", e)

schedule.every().day.at("08:00").do(send_report)
schedule.every().day.at("20:00").do(send_report)

while True:
    schedule.run_pending()
    time.sleep(60)
